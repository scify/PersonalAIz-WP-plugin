<?php
require_once('MyNewsRecommender.php');

$MyNewsRecommender = new MyNewsRecommender();

$MyNewsRecommender->initUsers();

?>