# PersonalAIz-WP-plugin

INSTALLATION

To install this plugin from Dashboard, go Plugins -> Add New -> Upload Plugin, 
select the .zip file and click Install Now. After the plugin has installed,
click on Activate Plugin.

At this point, connection settings to Recommendation Engine must be provided(see bellow).
After the connections settings are filled, the plugin must be DEACTIVATED and REACTIVATED.
This is required for the plugin to add all Wordpress users to the Recommendation Engine.



SETTINGS

The settings of the plugin can be found at the Dashboard under Settings -> My News Recommender Settings.

In the Settings page, in order to be able to communicate with the Recommendation Engine,
ip,port,username and password are required.
